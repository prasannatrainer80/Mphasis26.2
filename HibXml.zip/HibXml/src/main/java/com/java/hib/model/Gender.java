package com.java.hib.model;

public enum Gender {
	MALE, FEMALE
}
