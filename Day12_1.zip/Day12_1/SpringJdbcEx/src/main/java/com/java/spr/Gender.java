package com.java.spr;

public enum Gender {
	MALE, FEMALE
}
